#!/bin/sh

FLOPDEV=/dev/fd0

echo
cat <<END
   This is the 'blueflops' install script.
You can exit it at any time with ^C.
Need I say that all data previously on the floppies
 WILL BE LOST ?
END
echo

write_error ()
{
 echo -en "\033[1;31mError writing image on the $1 floppy!\n"\
"Replace the bad disk and run the script again.\033[0m\n"\
"Press <ENTER> to exit ..."
 read BOGUS
 exit 1
}

if [ -z "$1" ]; then
echo "Insert the first floppy disk (label it 'blueflops 1')"
echo -n "and press <ENTER> ..."
read BOGUS
echo -n " writing image ..." && cat bf-1.img > $FLOPDEV && sleep 2
echo -ne "\n verifying image ..." && cmp bf-1.img /dev/fd0 || write_error first
echo
fi

echo "Insert the second floppy disk (label it 'blueflops 2')"
echo -n "and press <ENTER> ..."
read BOGUS
echo -n " writing image ..." && cat bf-2.img > $FLOPDEV && sleep 2
echo -ne "\n verifying image ..." && cmp bf-2.img /dev/fd0 || write_error second
echo -e "\n\nInstallation completed..."
echo "                       ...now it's up to you"
echo
