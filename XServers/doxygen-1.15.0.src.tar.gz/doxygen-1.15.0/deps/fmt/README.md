The include dir contains a copy of the files in deps/spdlog/include/spdlog/fmt/bundled
which is based on fmt version 11.2.0 see https://github.com/fmtlib/fmt/releases
