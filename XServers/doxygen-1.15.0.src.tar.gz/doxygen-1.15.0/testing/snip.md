[SUB]
# Included Section 1.1

Some text in SUB section.

@snippet{doc,raise=1} snip.md SUBSUB
[SUB]
[SUBSUB]
# Included Section x.1.1

Some text in SUBSUB section.
[SUBSUB]
