// objective: test the \package command
// check: namespaceorg_1_1doxygen_1_1_test.xml

package org.doxygen.Test;

/** @package org.doxygen.Test
 *  A test package.
 */
